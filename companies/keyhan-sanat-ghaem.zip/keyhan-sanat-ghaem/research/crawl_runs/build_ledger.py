"""Local assembly helper. Ignored by git; all observations come from cited public receipts."""
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
D = ROOT / 'discovery' / '2026-10-30'
surfaces = json.loads((D / 'public_surface_review.json').read_text(encoding='utf-8'))['pages']
apis = json.loads((D / 'advertised_page_api_receipts.json').read_text(encoding='utf-8'))['requests']
surface = {p['url']: p for p in surfaces}
api = {p['page_url']: p for p in apis}
pdf = json.loads((D / 'catalog_review.json').read_text(encoding='utf-8'))

sources_path = ROOT / 'SOURCES.csv'
with sources_path.open(encoding='utf-8', newline='') as f:
    reader = csv.DictReader(f)
    fields = reader.fieldnames
    sources = list(reader)
new = [
('S08','https://www.ksgco.com/units/quality-control/','کنترل کیفیت','معرفی نظارت بر چرخه تولید و رضایت مشتری'),
('S09','https://www.ksgco.com/products/','محصولات','فهرست شش گروه محصول'),
('S10','https://www.ksgco.com/products/passengercars/','سواری','برندها برای معرفی‌اند؛ لینک تصویری کاتالوگ'),
('S11','https://www.ksgco.com/products/truck/','کامیونی','گروه محصول و لینک کاتالوگ مشترک'),
('S12','https://www.ksgco.com/products/road-machines/','راه‌سازی','گروه محصول و لینک کاتالوگ مشترک'),
('S13','https://www.ksgco.com/products/agriculture/','کشاورزی','گروه محصول و لینک کاتالوگ مشترک'),
('S14','https://www.ksgco.com/products/railway/','ریلی','معرفی گروه؛ لینک PDF در HTML این صفحه مشاهده نشد'),
('S15','https://www.ksgco.com/products/seegroup/','دریایی','گروه محصول و لینک کاتالوگ مشترک'),
('S16','https://www.ksgco.com/quality/','کیفیت','وجود متن نمونه لاتین در بدنه؛ نیاز به بازبینی محتوا'),
('S17','https://www.ksgco.com/quality/certificates/','گواهینامه‌ها','ادعاهای تاریخی؛ اعتبار فعلی گواهینامه بررسی نشده'),
('S18','https://www.ksgco.com/quality/qualitypolicies/','خط مشی کیفیت','اهداف کاهش هزینه و تحویل به‌موقع؛ بدون داده تحقق'),
('S19','https://www.ksgco.com/%d8%ae%d8%a8%d8%b1%d9%86%d8%a7%d9%85%d9%87/','خبرنامه','اعلام نشان استاندارد و لینک‌های گروه؛ اعتبار جاری نامشخص'),
('S20','https://www.ksgco.com/aboutus/history/','تاریخچه','معرفی تاریخی شرکت'),
('S21','https://www.ksgco.com/quality-2/','کیفیت؛ نسخه دیگر','صفحه عمومی مرتبط؛ تعیین نسخه مرجع نیازمند صاحب محتوا'),
('S22','https://www.ksgco.com/robots.txt','قواعد دسترسی','منع wp-admin و اعلام sitemap؛ مجوز کلی API مدیریتی نیست'),
('S23','https://www.ksgco.com/wp-sitemap.xml','sitemap index','دو sitemap اعلام شده؛ شاخه کاربران خوانده نشد'),
('S24','https://www.ksgco.com/wp-sitemap-posts-page-1.xml','sitemap صفحات','۲۵ نشانی؛ تطبیق با فهرست HTML انجام شد'),
('S25','https://www.ksgco.com/wp-json/?_fields=name,description,url,home,namespaces','API عمومی؛ نمایه','فقط فراداده و namespace؛ بدون داده کاربران'),
('S26','https://www.ksgco.com/wp-json/wp/v2/pages/51?_fields=id,date_gmt,modified_gmt,link,status,type','API صفحه اصلی','تاریخ‌های CMS؛ نه گواه وضعیت فعلی شرکت'),
('S27','https://developer.wordpress.org/rest-api/using-the-rest-api/discovery/','WordPress Discovery','معنای لینک اعلام‌شده REST API'),
('S28','https://developer.wordpress.org/rest-api/using-the-rest-api/global-parameters/','WordPress _fields','محدودکردن پاسخ به فراداده لازم'),
('S29','https://www.itl.nist.gov/div898/handbook/pmc/section1/pmc12.htm','NIST SPC','روش‌های پایه و فازهای پایش فرایند'),
('S30','https://www.nist.gov/publications/nistsematech-engineering-statistics-handbook-chapter-2-measurement-process','NIST Measurement Process','تکرارپذیری و تجدیدپذیری و ثبات و عدم‌قطعیت'),
('S31','https://ghaemg.com/%D8%B9%DB%8C%D8%A8-%DB%8C%D8%A7%D8%A8%DB%8C-%D8%AE%D8%B1%D8%A7%D8%A8%DB%8C-%D8%A8%D9%88%D8%B4-%D8%B3%DB%8C%D9%84%D9%86%D8%AF%D8%B1/','مقاله بیرونی لینک‌شده','ابزار وب 404 گزارش کرد؛ مبنای ادعای عیب محصول نیست'),
('S32','https://www.ksgco.com/aboutus/','درباره ما','معرفی تاریخی؛ داده جاری عملیات نیست'),
('S33','https://www.ksgco.com/units/','واحدها','معرفی اتصال خطوط تولید؛ نه تأیید ردیابی دیجیتال'),
('S34','https://www.ksgco.com/aboutus/omessage/','پیام سازمان','معرفی عمومی؛ تعهد همکاری پژوهشی نیست'),
('S35','https://www.ksgco.com/%d8%aa%d9%88%d8%a7%d9%86%d9%85%d9%86%d8%af%db%8c-%d9%87%d8%a7%db%8c-%d8%b3%d8%a7%d8%b2%d9%85%d8%a7%d9%86/','توانمندی‌ها','مسیر منوی عمومی به واحدهای فنی'),
('S36',pdf['source_url'],'کاتالوگ فنی PDF','۲۸۵ صفحه؛ متن ۲۸۳ صفحه استخراج‌پذیر؛ نسخه جاری تأیید نشده'),
]
existing = {s['source_id'] for s in sources}
for sid,url,title,context in new:
    if sid not in existing:
        sources.append(dict(zip(fields,[sid,url,title,context,'2026-10-30','public_review_2026-10-30' if sid!='S31' else 'web_tool_404_not_independently_confirmed'])))
with sources_path.open('w',encoding='utf-8',newline='') as f:
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(sources)
S={s['source_id']:s for s in sources}

rows=[]
def add(cid,claim,sid,location,kind='FACT_PUBLIC',paraphrase='',parents='',limits='',publication='UNKNOWN',confidence=None):
    url=S[sid]['url']; p=surface.get(url)
    observed = p['observed_at_utc'] if p else '2026-10-30'
    pub = publication
    if pub=='UNKNOWN' and url in api:pub=api[url].get('public_metadata',{}).get('date_gmt','UNKNOWN')+'Z (CMS)'
    rows.append({'claim_id':cid,'claim_fa':claim,'source_url':url,'exact_location':location,'observed_date':'2026-10-30','evidence_type':kind,'confidence':confidence or ('high_for_public_observation_only' if kind=='FACT_PUBLIC' else 'conditional' if kind in {'ENGINEERING_INFERENCE','OPPORTUNITY_HYPOTHESIS'} else 'NOT_PUBLICLY_VERIFIABLE'),'possible_staleness':'high_for_current_operations' if sid in {'S01','S02','S03','S04','S05','S06','S17','S36'} else 'point_in_time_observation','independent_verification':'not_independently_verified' if kind=='FACT_PUBLIC' else 'not_applicable_or_not_performed','publication_decision':'publish_with_limits_no_private_data','source_id':sid,'observed_at_utc':observed,'publication_date':pub,'excerpt_or_paraphrase':paraphrase or claim,'parent_claim_ids':parents,'verification_limits':limits or 'این شاهد فقط متن یا پاسخ عمومی منبع را تأیید می‌کند؛ وضعیت کارخانه را اثبات نمی‌کند.'})

add('E01','معرفی عمومی شرکت سال تأسیس را ۱۳۷۳ و محصول را بوش سیلندر بیان می‌کند.','S01','درباره ما / footer')
add('E02','فهرست عمومی شش گروه سواری، کامیونی، راه‌سازی، کشاورزی، ریلی و دریایی دارد.','S09','گروه‌های محصولات')
add('E03','واحد ماشین‌کاری استفاده از CNC و تولید ناب را معرفی می‌کند.','S02','پاراگراف دوم واحد ماشین‌کاری')
add('E04','واحد ریخته‌گری روش‌های گریز از مرکز، پوسته‌ای، ماسه‌ای، ذوب القایی و کنترل مواد ورودی را معرفی می‌کند؛ رقم بیش از ۲۰۰۰۰ تن در سال خوداظهاری صفحه است و تولید جاری تأیید نشده است.','S03','دو پاراگراف معرفی')
add('E05','آزمایشگاه ایرگیج برای سنجش قطر داخل و پشت را نام می‌برد.','S04','فهرست تجهیزات / ایرگیج')
add('E06','عبارت منبع «ابزارآلات اندازه گیری با دقت ۰٫۰۰۱ میلی‌متر» است؛ تعریف مترولوژیک این عدد در صفحه روشن نیست.','S04','فهرست تجهیزات / ابزارآلات',paraphrase='عدد ۰٫۰۰۱ در متن شرکت با واژه دقت آمده؛ آن را به عدم‌قطعیت یا تفکیک‌پذیری قطعی تبدیل نمی‌کنیم.')
add('E07','متالوگرافی، سختی و زبری در فهرست آزمایشگاه ذکر شده‌اند.','S04','فهرست تجهیزات و حوزه فعالیت')
add('E08','صفحه R&D تشکیل این واحد را در ارتباط با اهداف تجاری معرفی می‌کند؛ پروژه یا داده عمومی عملیاتی ارائه نمی‌کند.','S05','تنها پاراگراف اختصاصی')
add('E09','مأموریت شامل دریافت بازخورد، جستجو و مقایسه و پیگیری درخواست مشتری است.','S06','فهرست اهداف')
add('E10','کنترل کیفیت، نظارت بر مواد، تولید و رضایت مشتری را توصیف می‌کند.','S08','پاراگراف‌های اختصاصی واحد')
add('E11','صفحه ماشین‌کاری عدد بیش از ۱۸۰۰۰۰ قطعه در ماه را اعلام کرده است؛ تولید فعلی یا بهره‌برداری واقعی تأیید نشده است.','S02','پاراگراف پایانی معرفی',limits='عدد تاریخی خوداظهاری است؛ در تخمین سود یا نرخ تولید به کار نرفت.')
add('E12','فراداده عمومی CMS برای ماشین‌کاری زمان تغییر 2018-03-23 و برای آزمایشگاه 2019-08-06 ثبت کرده است.','S02','alternate JSON؛ pages/160 و pages/162',paraphrase='دو endpoint دقیق از HTML معرفی شدند؛ فقط date_gmt و modified_gmt و وضعیت انتشار خوانده شد.',limits='تاریخ تغییر رکورد CMS تاریخ بازبینی مهندسی یا آخرین تغییر همه اجزای صفحه نیست.')
add('E13','صفحه اصلی ISO 9001:2015 و IATF 16949:2016 را در فهرست گواهینامه‌ها ذکر می‌کند.','S01','سایر افتخارات و گواهینامه‌ها',limits='وجود ادعا گواه اعتبار امروز یا دامنه محصول نیست.')
add('E14','صفحه گواهینامه‌ها در متن از ISO 9001:2008 و ISO/TS 16949:2002 نام می‌برد.','S17','پاراگراف دوم گواهینامه‌ها',limits='با E13 تفاوت نسخه متن دارد؛ ابطال یا عدم رعایت استاندارد از آن نتیجه نمی‌شود.')
add('E15','در بدنه صفحه کیفیت، عنوان و بندهای لاتین نمونه وجود دارد.','S16','بخش بعد از تصاویر گواهینامه',paraphrase='نشانگر کوتاه: Phasellus semper eu pulvinar mollis',limits='وجود متن در HTML و متن استخراج‌شده تأیید شد؛ تأثیر بر فروش یا کیفیت تولید اندازه‌گیری نشده است.')
add('E16','پنج صفحه گروه محصول به همان PDF مشترک GHAEM-2015.pdf پیوند دارند.','S10','لینک تصویری کنار معرفی کاتالوگ',parents='E02',limits='سواری، کامیونی، راه‌سازی، کشاورزی و دریایی؛ در HTML ریلی لینک PDF دیده نشد. نبود در این HTML اثبات نبود کاتالوگ جای دیگر نیست.')
add('E17','PDF لینک‌شده ۲۸۵ صفحه دارد؛ متن ۲۸۳ صفحه استخراج شد و صفحه PDF ۳ کد قطعه، طرح و فیلدهای ابعادی دارد.','S36','PDF page 3 = printed page 1؛ شمارش کل فایل',paraphrase='دریافت مستقیم HTTPS موفق؛ تحلیل ساختار کل و بازبینی تصویری صفحه ۳. نمونه عنوان داخلی KSG.2015 و در صفحه ۴۸ KSG.2014 دیده شد.',limits='تمام جداول به‌صورت دستی تأیید نشده‌اند. اعداد اسمی کاتالوگ، تلرانس نقشه، موجودی یا سبد تولید فعلی نیستند.',publication='UNKNOWN; internal labels KSG.2015/KSG.2014')
add('E18','robots.txt منع wp-admin و sitemap عمومی را اعلام می‌کند؛ صفحات پژوهش‌شده منع نشده‌اند.','S22','کل فایل قواعد',limits='Allow برای admin-ajax مجوز عملیات یا ارسال فرم نیست؛ هیچ مسیر مدیریت فراخوانی نشد.')
add('E19','HTML و هدر صفحه اصلی ریشه REST API و JSON همان صفحه را صریحاً معرفی می‌کنند؛ پاسخ محدود فراداده 200 بود.','S26','Link header و link rel alternate؛ pages/51',parents='E18',limits='API محتوای عمومی وب است؛ دسترسی تولید یا ERP از آن نتیجه نمی‌شود.')
add('E20','NIST کنترل نموداری، Shewhart، EWMA و CUSUM و جدایی فاز مبنا از پایش بعدی را توضیح می‌دهد.','S29','What are Process Control Techniques?',limits='مرجع روش است؛ شواهد عملکرد این شرکت نیست.')
add('E21','NIST تکرارپذیری، تجدیدپذیری، ثبات، کالیبراسیون و عدم‌قطعیت را موضوع ارزیابی نظام اندازه‌گیری می‌داند.','S30','Abstract',publication='2003-06-01',limits='مرجع روش است؛ مطالعه MSA این شرکت در دسترس نیست.')
add('E22','sitemap صفحات دقیقاً ۲۵ URL دارد و با ۲۵ صفحه فهرست‌برداری‌شده تطبیق دارد.','S24','urlset / loc',parents='E18',limits='پوشش فهرست اعلام‌شده در همان زمان؛ تضمین همه محتوای پنهان، بیرونی یا رندرشده نیست.')
add('E23','در بررسی ۲۵ HTML، فهرست نوع‌های JSON-LD قابل استخراج در خروجی ابزار خالی بود.','S09','فیلد json_ld_types در public_surface_review.json',limits='این خروجی وجود همه شکل‌های داده ساختاریافته یا تزریق با JS را نفی نمی‌کند؛ نبود پایگاه داده محصول ثابت نشده و به‌تنهایی مشکل جدی تلقی نمی‌شود.')
add('E24','پیوند PDF در صفحات محصول با HTTP درج شده ولی دریافت همان فایل با HTTPS موفق بود.','S10','href لینک تصویری کاتالوگ',parents='E16;E17',limits='HTTP در href مشاهده شد؛ مسدودشدن مرورگر، حمله یا آسیب امنیتی آزموده نشده است.')
add('E25','در HTML و متن استخراج‌شده صفحه اصلی، نشانگر shortcode شبکه اجتماعی باقی است.','S01','پیش از بخش تماس',paraphrase='نشانگر [aps-social id=…]؛ مقدار شناسه کاربردی نیست.',limits='عدم اجرای پلاگین یا خرابی در مرورگر زنده تأیید نشده؛ یافته فرعی با اولویت پایین.')
add('E26','صفحه تماس، ایمیل عمومی شرکتی و فرم تماس را نمایش می‌دهد.','S07','اطلاعات دفتر/کارخانه و فرم',limits='هیچ اطلاعاتی وارد یا ارسال نشد؛ تحویل ایمیل و گردش درخواست تأیید نشده است.')
add('E27','دو مسیر عمومی quality/ و quality-2/ محتوای گواهینامه مرتبط دارند و در sitemap هستند.','S21','بدنه و sitemap',parents='E14;E15;E22',limits='وجود چند مسیر مشاهده است؛ اثر SEO یا افت ترافیک اندازه‌گیری نشده است.')
add('E28','صفحات محصول تصریح می‌کنند نام برندها برای شناسایی است و تأمین مستقیم را نمی‌رساند.','S10','توضیح ابتدای گروه محصول',limits='از فهرست برندها رابطه OEM یا مشتری فعلی استنباط نشود.')
add('E29','ابزار وب برای مقاله بیرونی عیب‌یابی لینک‌شده در خبرنامه خطای 404 گزارش کرد.','S31','پیوند از خبرنامه رسمی',limits='فقط خطای همین ابزار؛ خطای مبدأ مستقلاً تأیید نشد و مدرک عیب محصولات شرکت نیست.')
add('E30','سنجش قطر و CNC زنجیره مناسبی برای پرسش محدود پایش ابعادی می‌سازند.','S04','برداشت از E03 و E05–E07','ENGINEERING_INFERENCE',parents='E03;E05;E06;E07;E20;E21',limits='وجود سنجش دیجیتال ترتیبی، SPC فعلی و اهمیت اقتصادی نامعلوم است.')
add('E31','واحد R&D و هدف استفاده از بازخورد، گفت‌وگو درباره ثبت تجربه را مرتبط می‌کند.','S05','برداشت مهندسی','ENGINEERING_INFERENCE',parents='E08;E09',limits='نبود سامانه مستندسازی احراز نشده است.')
add('E32','در صورت ثبت چرخه ابزار و کیفیت، بررسی سیاست ابزار برای CNC قابل طرح است.','S02','برداشت مهندسی','ENGINEERING_INFERENCE',parents='E03',limits='هیچ توقف، خرابی یا ابزار نامناسب مشاهده نشده است.')
add('E33','در صورت اتصال بچ به آزمون نهایی، تحلیل رابطه شرایط ذوب و کیفیت قابل بررسی است.','S03','برداشت مهندسی','ENGINEERING_INFERENCE',parents='E04;E07;E10',limits='شناسنامه مواد با ردیابی دیجیتال تا قطعه برابر نیست؛ رابطه علّی هنوز قابل طرح نیست.')
add('E34','مأموریت دریافت بازخورد، پرسش از وجود داده خدمت را مرتبط می‌کند؛ خبرنامه شاهد خرابی نیست.','S06','برداشت مهندسی','ENGINEERING_INFERENCE',parents='E09;E10;E29',limits='اصل وجود پرونده شکایت، حجم و علت آن نامعلوم است.')
add('E35','تفاوت متن گواهینامه و قدمت فراداده، ضرورت تعیین نسخه مرجع عمومی را مطرح می‌کند.','S17','برداشت محتوایی','ENGINEERING_INFERENCE',parents='E12;E13;E14;E27',limits='عدم انطباق قانونی، ابطال گواهی یا خسارت احراز نشده است.')
for cid,claim,sid,parents in [
('E40','آیا پایش یک قطر با بودجه هشدار برابر از روش فعلی سودمندتر است؟','S04','E30'),
('E41','آیا قالب حداقلی ثبت آزمایش R&D زمان بازیابی تصمیم را کاهش می‌دهد؟','S05','E31'),
('E42','آیا سیاست بازبینی ابزار با داده مجاز از سیاست فعلی بهتر است؟','S02','E32'),
('E43','آیا ردیابی ذوب تا کیفیت به تصمیم قابل اقدام منتهی می‌شود؟','S03','E33'),
('E44','آیا دسته‌بندی بازخورد خدمتِ موجود و مجاز به تصمیم مهندسی کمک می‌کند؟','S06','E34'),
('E45','آیا نمونه کوچک جستجوی کد قطعه با نسخه مرجع کاتالوگ به یافتن محصول کمک می‌کند؟','S36','E09;E16;E17;E28'),
]: add(cid,claim,sid,'پرسش آزمون در ثبت فرصت‌ها/اقدامات','OPPORTUNITY_HYPOTHESIS',parents=parents,limits='پیشنهاد مشروط؛ اجرای واقعی، برتری و صرفه‌جویی اثبات نشده است.')
for cid,claim,sid in [
('E50','نرخ جاری ضایعات و بازکاری و زیان مالی شرکت معلوم نیست.','S02'),
('E51','وجود SPC، MSA و داده سنجش ترتیبی قابل خروج معلوم نیست.','S04'),
('E52','ظرفیت و ترکیب محصول و تعداد کارکنان فعلی معلوم نیست.','S02'),
('E53','اعتبار امروز، تاریخ انقضا و دامنه جاری گواهینامه‌ها تأیید نشده است.','S17'),
('E54','داده شکایت مشتری و نرخ خرابی واقعی در دسترس عمومی مجاز تأیید نشده است.','S06'),
('E55','API تولید، ماشین، ERP یا داده عملیاتی از منابع بررسی‌شده معرفی و تأیید نشد.','S25'),
('E56','عملکرد فرم، ظاهر موبایل، کنسول و ترافیک درخواست مرورگر آزموده نشده است.','S07'),
('E57','به‌روز بودن کاتالوگ و عرضه فعلی هر کد آن نیازمند تأیید شرکت است.','S36'),
('E58','علاقه شرکت، سفارش یا مجوز همکاری اختصاصی وجودش تأیید نشده است.','S05'),
]:add(cid,claim,sid,'حد اعتبار پژوهش عمومی','UNKNOWN',limits='NOT_PUBLICLY_VERIFIABLE؛ نبود شاهد به معنای نبود سامانه یا وجود نقص نیست.')

cols=['claim_id','claim_fa','source_url','exact_location','observed_date','evidence_type','confidence','possible_staleness','independent_verification','publication_decision','source_id','observed_at_utc','publication_date','excerpt_or_paraphrase','parent_claim_ids','verification_limits']
with (ROOT/'EVIDENCE_LEDGER.csv').open('w',encoding='utf-8',newline='') as f:
    w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows(rows)

lines=['# فهرست API و منابع ماشین‌خوان عمومی — 2026-10-30','',
'کشف از HTML و هدر `Link` انجام شد؛ مسیر یا شناسه حدس زده نشد. فقط GET بدون حساب و با محدودکردن فیلدهای پاسخ انجام شد. این فهرست درباره محتوای وب است؛ API کارخانه در منابع بررسی‌شده تأیید نشد (`NOT_PUBLICLY_VERIFIABLE`).','',
'- ریشه اعلام‌شده: https://www.ksgco.com/wp-json/ ؛ درخواست محدود: [فراداده ریشه](https://www.ksgco.com/wp-json/?_fields=name,description,url,home,namespaces)، پاسخ 200.',
'- هر صفحه، alternate اختصاصی از نوع `application/json` داشت؛ ۲۵ مورد زیر با `_fields=id,date_gmt,modified_gmt,link,status,type` خوانده شد و همگی 200 و `status=publish` داشتند.',
'- پارامتر `_fields` بر اساس [مستندات رسمی WordPress](https://developer.wordpress.org/rest-api/using-the-rest-api/global-parameters/) است؛ روش اعلام لینک در [Discovery](https://developer.wordpress.org/rest-api/using-the-rest-api/discovery/) توضیح داده شده است.',
'- داده کاربران/نویسندگان، دیدگاه‌ها، محتوای کامل، توکن، کوکی یا داده تولید درخواست یا ذخیره نشد.','',
'| صفحه عمومی اعلام‌کننده | endpoint دقیق اعلام‌شده | آخرین تغییر ثبت‌شده CMS (UTC) |','|---|---|---|']
for x in apis:
    lines.append(f"| [{x['page_url'].replace('https://www.ksgco.com','')}]({x['page_url']}) | [{x['advertised_endpoint'].split('/wp-json/')[-1]}]({x['url']}) | {x.get('public_metadata',{}).get('modified_gmt','UNKNOWN')}Z |")
lines += ['', '## اعلام‌شده ولی فراخوانی نشده', '',
'- لینک‌های oEmbed هر صفحه، RSS و خوراک دیدگاه‌ها فقط ثبت شدند؛ برای پرسش صنعتی نیاز نبود. `xmlrpc.php?rsd` و `wlwmanifest.xml` معرفی متادیتا هستند و فراخوانی نشدند.',
'- namespaceهای `contact-form-7/v1`، `wp-site-health/v1` و `wp-block-editor/v1` در فراداده ریشه دیده شدند؛ وجودشان مجوز دسترسی عمومی به همه مسیرها نیست. هیچ زیرمسیر آن‌ها خوانده نشد.',
'- پیکربندی عمومی frontend به `wp-admin/admin-ajax.php` اشاره داشت؛ فقط مشاهده شد و درخواست مستقلی به آن انجام نشد؛ فرم تماس هم ارسال نشد.',
'- sitemap کاربران اعلام شده بود و عمداً خوانده نشد. فقط sitemap صفحات عمومی خوانده شد.',
'', '## چه چیزی نتیجه نمی‌شود؟', '',
'وجود REST API وردپرس به معنای دسترسی به CNC، تجهیزات سنجش، PLC، MES یا ERP نیست. timestamp قدیمی رکورد CMS به‌تنهایی اثبات نمی‌کند تجهیزات یا فعالیت کارخانه قدیمی‌اند. شماره نسخه فایل‌های پوسته/پلاگین، مدرک آسیب‌پذیری یا نیاز قطعی به وصله خاص نیست؛ ممیزی امنیتی انجام نشده است.',
'', '## رسیدها', '',
'[رسید ریشه و قواعد](discovery/2026-10-30/access_and_api_receipts.json) · [رسید ۲۵ صفحه API](discovery/2026-10-30/advertised_page_api_receipts.json) · [لینک‌های کشف‌شده در HTML](discovery/2026-10-30/public_inventory.json). پاسخ‌ها به فراداده لازم محدود شده‌اند؛ HTML و PDF کامل در مخزن نیستند.']
(ROOT/'PUBLIC_API_INVENTORY.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print(f'Generated {len(sources)} sources, {len(rows)} evidence claims, {len(apis)} API rows.')
