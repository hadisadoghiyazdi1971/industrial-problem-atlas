"""Task-specific local checks; no remote network or rendering claims."""
import csv
import functools
import json
import re
import subprocess
import threading
from collections import Counter
from datetime import datetime, timezone
from html.parser import HTMLParser
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urljoin, urlsplit
from urllib.request import urlopen

ROOT = Path(__file__).resolve().parents[4]
COMPANY = ROOT / 'companies/keyhan-sanat-ghaem'
RESEARCH = COMPANY / 'research'
checks = []
errors = []

def check(name, condition, detail=None):
    checks.append({'name': name, 'passed': bool(condition), 'detail': detail})
    if not condition:
        errors.append(name)

class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links=[]
        self.ids=set()
        self.lang=None
        self.direction=None
        self.viewport=False
        self.refresh=None
        self.canonical=None
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if a.get('id'): self.ids.add(a['id'])
        if tag=='html': self.lang=a.get('lang');self.direction=a.get('dir')
        if tag in {'a','link','script'}:
            target=a.get('src') if tag=='script' else a.get('href')
            if target:self.links.append(target)
        if tag=='meta' and a.get('name')=='viewport': self.viewport=True
        if tag=='meta' and a.get('http-equiv','').lower()=='refresh':self.refresh=a.get('content')
        if tag=='link' and a.get('rel')=='canonical':self.canonical=a.get('href')

required = ['research/RESEARCH_REPORT_FA.md','research/EVIDENCE_LEDGER.csv','research/OPPORTUNITY_REGISTER.md',
 'research/CODEX_RUN_REPORT.md','research/CHATGPT_HANDOFF_FA.md','research/ACTION_REGISTER_FA.md',
 'research/PUBLIC_API_INVENTORY.md','proposals/IPA-004_PROPOSAL_FA.md','outreach/DRAFT_EMAIL_FA.md','index.html']
check('required_deliverables',all((COMPANY/p).is_file() for p in required))
html_paths=[COMPANY/'index.html',ROOT/'companies/index.html',ROOT/'cases/keyhan-sanat-ghaem.html']
htmls={p: p.read_text(encoding='utf-8') for p in html_paths}
local_links=[]
for path,content in htmls.items():
    parser=Links();parser.feed(content)
    check(f'persian_rtl:{path.relative_to(ROOT)}',parser.lang=='fa' and parser.direction=='rtl')
    check(f'viewport:{path.relative_to(ROOT)}',parser.viewport)
    local_links.extend((path,link) for link in parser.links)
for path in COMPANY.rglob('*.md'):
    if 'crawl_runs' in path.parts:continue
    content=path.read_text(encoding='utf-8')
    local_links.extend((path,link) for link in re.findall(r'\[[^\]]*\]\(([^)]+)\)',content))
broken=[]
fragments=[]
for source,link in local_links:
    target=urlsplit(link)
    if target.scheme or link.startswith('//'):continue
    path=(source.parent/unquote(target.path)).resolve() if target.path else source
    if not path.is_relative_to(ROOT) or not path.exists():broken.append(f'{source.relative_to(ROOT)}: {link}');continue
    if path.is_dir():path=path/'index.html'
    if target.fragment and path.suffix=='.html':
        p=Links();p.feed(path.read_text(encoding='utf-8'))
        if unquote(target.fragment) not in p.ids:fragments.append(f'{source.relative_to(ROOT)}: {link}')
check('local_html_markdown_links',not broken,{'count':len(local_links),'broken':broken})
check('html_fragments',not fragments,fragments)

with (RESEARCH/'SOURCES.csv').open(encoding='utf-8',newline='') as f:sources=list(csv.DictReader(f))
with (RESEARCH/'EVIDENCE_LEDGER.csv').open(encoding='utf-8',newline='') as f:claims=list(csv.DictReader(f))
sids={x['source_id']:x for x in sources};cids={x['claim_id']:x for x in claims}
check('sources_unique',len(sids)==len(sources)==36)
check('claims_unique',len(cids)==len(claims)==50)
types={'FACT_PUBLIC','ENGINEERING_INFERENCE','OPPORTUNITY_HYPOTHESIS','UNKNOWN'}
check('claim_required_fields_and_types',all(x['evidence_type'] in types and all(x.get(k) for k in ['claim_fa','source_url','exact_location','observed_date','observed_at_utc','publication_date','excerpt_or_paraphrase','verification_limits']) for x in claims))
check('claim_source_consistency',all(x['source_id'] in sids and x['source_url']==sids[x['source_id']]['url'] for x in claims))
check('claim_parents_exist',all(p in cids for x in claims for p in x['parent_claim_ids'].split(';') if p))
visiting=set();visited=set()
def visit(cid):
    if cid in visiting:raise ValueError('cycle')
    if cid in visited:return
    visiting.add(cid)
    for p in cids[cid]['parent_claim_ids'].split(';'):
        if p:visit(p)
    visiting.remove(cid);visited.add(cid)
try:
    for cid in cids:visit(cid)
    acyclic=True
except (KeyError,ValueError):acyclic=False
check('evidence_graph_acyclic',acyclic)
referenced=set()
for path in COMPANY.rglob('*.md'):
    if 'crawl_runs' not in path.parts:referenced.update(re.findall(r'\bE\d{2}\b',path.read_text(encoding='utf-8')))
check('document_claim_ids_exist',referenced<=set(cids),sorted(referenced-set(cids)))
check('unknowns_explicitly_unverified',all(x['confidence']=='NOT_PUBLICLY_VERIFIABLE' for x in claims if x['evidence_type']=='UNKNOWN'))

D=RESEARCH/'discovery/2026-10-30'
inventory=json.loads((D/'public_inventory.json').read_text(encoding='utf-8'))
sitemap=json.loads((D/'page_sitemap_receipt.json').read_text(encoding='utf-8'))
api=json.loads((D/'advertised_page_api_receipts.json').read_text(encoding='utf-8'))['requests']
check('declared_sitemap_coverage',len(inventory['pages'])==len(sitemap['urls'])==25 and {x['url'] for x in inventory['pages']}==set(sitemap['urls']))
check('crawl_no_recorded_errors',inventory['errors']==[])
allowed_fields={'id','date_gmt','modified_gmt','link','status','type'}
check('public_api_receipts_minimized',len(api)==25 and all(x['status']==200 and set(x['public_metadata'])<=allowed_fields and not x['credentials'] and x['method']=='GET' for x in api))
check('api_endpoints_actually_advertised',all(x['advertised_endpoint'] in {l['href'] for p in inventory['pages'] if p['url']==x['page_url'] for l in p['public_resource_links_advertised_not_queried']} for x in api))
catalog_receipt=json.loads((D/'catalog_review.json').read_text(encoding='utf-8'))
check('catalog_counts_supported',catalog_receipt['page_count']==285 and catalog_receipt['pages_with_extractable_text']==283 and catalog_receipt['size_bytes']==5874441)

catalog=json.loads((ROOT/'data/problems.json').read_text(encoding='utf-8'))
previous=json.loads(subprocess.check_output(['git','show','HEAD:data/problems.json'],cwd=ROOT))
check('other_cases_preserved',[p for p in catalog['problems'] if p['id']!='IPA-004']==[p for p in previous['problems'] if p['id']!='IPA-004'])
ipa=[p for p in catalog['problems'] if p['id']=='IPA-004']
check('ipa004_identity_status_route',len(ipa)==1 and ipa[0]['status']=='concept' and ipa[0]['evidence_level']=='public_source' and ipa[0]['case_url']=='companies/keyhan-sanat-ghaem/')
check('company_listing_route','href="keyhan-sanat-ghaem/"' in htmls[ROOT/'companies/index.html'])
legacy=Links();legacy.feed(htmls[ROOT/'cases/keyhan-sanat-ghaem.html'])
check('historical_redirect_route',legacy.canonical=='../companies/keyhan-sanat-ghaem/' and legacy.refresh=='0; url=../companies/keyhan-sanat-ghaem/')
old_sources=list(csv.DictReader(subprocess.check_output(['git','show','HEAD:companies/keyhan-sanat-ghaem/research/SOURCES.csv'],cwd=ROOT).decode('utf-8').splitlines()))
check('prior_sources_preserved',sources[:len(old_sources)]==old_sources)
changed=subprocess.check_output(['git','diff','--name-only'],cwd=ROOT).decode().splitlines()
check('tracked_changes_scoped',all(p.startswith('companies/keyhan-sanat-ghaem/') or p=='data/problems.json' for p in changed),changed)

class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(QuietHandler,directory=str(ROOT)))
thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
http_results=[]
try:
    base=f'http://127.0.0.1:{server.server_port}'
    for route in ['/', '/companies/', '/companies/keyhan-sanat-ghaem/', '/problem.html?id=IPA-004', '/cases/keyhan-sanat-ghaem.html', '/data/problems.json', '/assets/style.css', '/assets/app.js']:
        with urlopen(base+route,timeout=5) as r:
            body=r.read();http_results.append({'route':route,'status':r.status,'bytes':len(body)})
    check('local_http_routes',all(x['status']==200 and x['bytes']>0 for x in http_results),http_results)
finally:server.shutdown();server.server_close();thread.join(timeout=5)

bad_encoding=[]
for path in COMPANY.rglob('*'):
    if not path.is_file() or 'crawl_runs' in path.parts:continue
    if path.suffix.lower() in {'.md','.csv','.html','.json'}:
        text=path.read_text(encoding='utf-8')
        if '\ufffd' in text or re.search(r'\?{4,}',text):bad_encoding.append(str(path.relative_to(ROOT)))
check('utf8_no_replacement_or_question_runs',not bad_encoding,bad_encoding)
check('no_full_remote_documents_committed',not any(p.suffix.lower() in {'.pdf','.png','.jpg','.jpeg','.har'} for p in COMPANY.rglob('*')))

result={'checked_at_utc':datetime.now(timezone.utc).isoformat(),'result':'PASS' if not errors else 'FAIL','scope':'Task-specific static, provenance and loopback HTTP checks. No JavaScript rendering or visual/mobile test. No remote requests in this verification.','source_count':len(sources),'evidence_count':len(claims),'evidence_types':dict(Counter(x['evidence_type'] for x in claims)),'checks':checks,'failed_checks':errors}
(RESEARCH/'verification_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(f"{result['result']}: {len(checks)} company checks; {len(http_results)} HTTP routes; {len(claims)} claims; {len(sources)} sources.")
for err in errors:print('FAILED:',err)
raise SystemExit(bool(errors))
